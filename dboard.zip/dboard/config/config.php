<?php
define('DB_HOST','192.168.137.1');
define('DB_USER', 'hermanfigueiredo');
define('DB_PASS', 'ispbenguela');
define('DATABASE', 'ispb_sistemarfid');
?>